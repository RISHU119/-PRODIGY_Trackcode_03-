
import React, { useState, useCallback } from 'react';
import { UploadIcon } from './icons/UploadIcon';

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  isLoading: boolean;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, isLoading }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onImageUpload(e.target.files[0]);
    }
  };

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onImageUpload(e.dataTransfer.files[0]);
    }
  }, [onImageUpload]);

  return (
    <div className="bg-white rounded-xl shadow-2xl p-6 md:p-10 transition-all duration-300 transform hover:scale-[1.01]">
      <div className="text-center mb-6">
        <h2 className="text-2xl md:text-3xl font-bold text-brand-dark">Upload an Image</h2>
        <p className="text-slate-500 mt-2">Let's classify if it's a Cat or a Dog!</p>
      </div>
      <div
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors duration-300 
          ${isDragging ? 'border-brand-primary bg-blue-50' : 'border-slate-300 bg-slate-50 hover:border-brand-secondary'}`}
      >
        <input
          type="file"
          id="file-upload"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          onChange={handleFileChange}
          accept="image/png, image/jpeg, image/webp"
          disabled={isLoading}
        />
        <label htmlFor="file-upload" className="flex flex-col items-center justify-center space-y-4">
          <UploadIcon className="w-12 h-12 text-brand-secondary" />
          <p className="text-slate-600 font-semibold">
            <span className="text-brand-primary">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-slate-400">PNG, JPG, or WEBP</p>
        </label>
      </div>
    </div>
  );
};
