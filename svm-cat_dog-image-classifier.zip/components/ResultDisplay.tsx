
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { ClassificationResult, Classification } from '../types';
import { CatIcon } from './icons/CatIcon';
import { DogIcon } from './icons/DogIcon';

interface ResultDisplayProps {
  imageUrl: string;
  result: ClassificationResult;
  onReset: () => void;
}

const renderResultIcon = (classification: Classification) => {
  switch (classification) {
    case Classification.Cat:
      return <CatIcon className="w-16 h-16 text-brand-primary" />;
    case Classification.Dog:
      return <DogIcon className="w-16 h-16 text-brand-primary" />;
    default:
        return (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        );
  }
};

const getClassificationText = (classification: Classification) => {
    if (classification === Classification.Unknown) {
        return "It's neither a cat nor a dog.";
    }
    return `The AI classified this as a ${classification}!`;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ imageUrl, result, onReset }) => {
  const chartData = [{ name: 'Confidence', value: result.confidence }];
  const barColor = result.confidence > 75 ? '#10b981' : result.confidence > 50 ? '#f59e0b' : '#ef4444';

  return (
    <div className="bg-white rounded-xl shadow-2xl overflow-hidden animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2">
        <div className="p-4 sm:p-6">
          <img src={imageUrl} alt="Uploaded for classification" className="rounded-lg w-full h-auto object-cover max-h-[400px]" />
        </div>
        <div className="p-6 flex flex-col justify-center">
          <div className="flex items-center space-x-4">
            {renderResultIcon(result.classification)}
            <div>
              <p className="text-sm text-slate-500">Analysis Complete</p>
              <h2 className="text-2xl md:text-3xl font-bold text-brand-dark">
                {getClassificationText(result.classification)}
              </h2>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-semibold text-slate-700">Confidence Score</h3>
            <div className="w-full h-20 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <XAxis type="number" domain={[0, 100]} hide />
                  <YAxis type="category" dataKey="name" hide />
                  <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ background: '#1e293b', border: 'none', borderRadius: '0.5rem' }} labelStyle={{ color: 'white' }} itemStyle={{ color: barColor }} />
                  <Bar dataKey="value" barSize={30} radius={[5, 5, 5, 5]}>
                    <Cell fill={barColor} />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <p className="text-center font-bold text-2xl" style={{color: barColor}}>{result.confidence.toFixed(1)}%</p>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-slate-700">Key Features (SVM Hyperplane)</h3>
            <ul className="mt-2 space-y-2">
              {result.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <svg className="w-5 h-5 text-brand-accent mr-2 flex-shrink-0 mt-1" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-slate-600">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="mt-8 text-center">
            <button
              onClick={onReset}
              className="px-8 py-3 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-brand-secondary focus:ring-offset-2 transition-all"
            >
              Classify Another Image
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
