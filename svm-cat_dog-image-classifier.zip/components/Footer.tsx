
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-dark text-slate-400 py-4 mt-8">
      <div className="container mx-auto px-4 text-center text-sm">
        <p>
          This application simulates an SVM classifier using the Google Gemini API. 
          It is for educational and demonstrative purposes only.
        </p>
        <p className="mt-1">&copy; {new Date().getFullYear()} AI Creations. All rights reserved.</p>
      </div>
    </footer>
  );
};
