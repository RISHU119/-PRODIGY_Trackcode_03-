
import { GoogleGenAI, Type } from '@google/genai';
import { ClassificationResult, Classification } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

export const classifyImage = async (file: File): Promise<ClassificationResult> => {
  try {
    const imagePart = await fileToGenerativePart(file);
    
    const prompt = `Analyze this image and determine if it contains a cat or a dog. 
      Your analysis should be similar to how a Support Vector Machine (SVM) works, focusing on key distinguishing features.
      If the image contains neither a cat nor a dog, or it's unclear, classify it as 'Unknown'.
      Provide a confidence score for your classification from 0 to 100.
      List the top 3-5 visual features you used for the classification.
      Return the result as a JSON object.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
          parts: [
              {text: prompt},
              imagePart
          ]
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            classification: {
              type: Type.STRING,
              description: "The classification of the animal in the image. Should be 'Cat', 'Dog', or 'Unknown'.",
              enum: ['Cat', 'Dog', 'Unknown']
            },
            confidence: {
              type: Type.NUMBER,
              description: 'A confidence score for the classification, ranging from 0 to 100.',
            },
            features: {
              type: Type.ARRAY,
              items: {
                type: Type.STRING,
              },
              description: 'An array of key visual features used for classification.',
            },
          },
          required: ['classification', 'confidence', 'features'],
        },
      }
    });

    const jsonString = response.text;
    const parsedResult = JSON.parse(jsonString);

    // Validate and cast the classification string to our enum
    let finalClassification: Classification;
    switch (parsedResult.classification) {
        case 'Cat':
            finalClassification = Classification.Cat;
            break;
        case 'Dog':
            finalClassification = Classification.Dog;
            break;
        default:
            finalClassification = Classification.Unknown;
            break;
    }

    return {
      classification: finalClassification,
      confidence: parsedResult.confidence,
      features: parsedResult.features,
    };

  } catch (error) {
    console.error('Error classifying image:', error);
    throw new Error('Failed to communicate with the AI model. Please check your API key and try again.');
  }
};
